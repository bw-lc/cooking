//
//  ViewController.h
//  onoff
//
//  Created by 陈明计 on 14-6-21.
//  Copyright (c) 2014年 陈明计. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
- (IBAction)settings:(id)sender;
- (IBAction)begin_open:(id)sender;
- (IBAction)end_open:(id)sender;
- (IBAction)begin_close:(id)sender;
- (IBAction)end_close:(id)sender;
- (IBAction)begin_open2:(id)sender;
- (IBAction)end_open2:(id)sender;
- (IBAction)begin_close2:(id)sender;
- (IBAction)end_close2:(id)sender;

@end
