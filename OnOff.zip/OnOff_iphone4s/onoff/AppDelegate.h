//
//  AppDelegate.h
//  onoff
//
//  Created by 陈明计 on 14-6-21.
//  Copyright (c) 2014年 陈明计. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
